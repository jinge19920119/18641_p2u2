Readme   project2 unit2.    

Name: Ge Jin.  andrew id: gjin


1. There are 3 packages in the src file, model, util and ui. 

2. Calculator method in model package, is used to represent an object and to calculate. MainActivity class in ui package is used as a java file compatible with the interface in activity_main.xml. ShowActivity class is used as a java file which is compatible with the second activity interface. DatabaseConnector class in Util package is used as a database which has insert and get methods. 

3. The outcome is listed and the comments are written in the code.